<?php

use Elementor\Widget_Base;

class Gutts_Vertical_SLider extends Widget_Base
{
	/**
	 * Get widget name.
	 *
	 * Retrieve widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name gutts_banner_slider.
	 */
	public function get_name()
	{
		return 'gutts_vertical_slider';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string  Gutts Banner Slider.
	 */
	public function get_title()
	{
		return __('Gutts Vertical Slider', 'elgutts');
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve gutts widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon dashicons-image-flip-vertical.
	 */
	public function get_icon()
	{
		return 'dashicons dashicons-image-flip-vertical';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the gutts widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['elgutts'];
	}

	/**
	 * Get widget construct.
	 *
	 * Retrieve the style and script of the Gutts Slider Widgets.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void.
	 */
	public function __construct($data = [], $args = null)
	{
		parent::__construct($data, $args);
		/* Script adding Area */
		wp_register_script('vertical-slider',plugin_dir_url(__DIR__).'assets/js/vertical-slider.js',[],'1.0.0',true);

		/* Style Adding Area */
		wp_register_style('vertical-slider',plugin_dir_url(__DIR__).'assets/css/vertical-slider.css');
	}


	public function get_script_depends()
	{
		return ['vertical-slider'];
	}

	public function get_style_depends()
	{
		return ['vertical-slider'];
		
	}

	/**
	 * Register Gutts banner widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{

		$this->start_controls_section(
			'gutts_vertical_slider_section',
			[
				'label' => __('Gutts Vertical Slider', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new \Elementor\Repeater();
        //slider title
		$repeater->add_control(
			'vertical_slider_title',
			[
				'label' => __('Slider Title', 'elgutts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __('Write Title', 'elgutts'),
				'label_block' => true,
			]
		);
        //slider subtitle
		$repeater->add_control(
			'vertical_slider_subtitle',
			[
				'label' => __('Slider Sub Title', 'elgutts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __('Write Sub Title', 'elgutts'),
				'label_block' => true,
                'separator' => 'after',
			]
		);
        //Slider background color
		$repeater->add_control(
			'slider_bg_color',
			[
				'label' => __( 'Slider Background Color', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
			]
		);
        //Slider background image
		$repeater->add_control(
			'vertical_slider_image',
			[
				'label' => __( 'Slider Image', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'description' => __('This image field will not match with your title field so testing is important to find best match'),
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

        //slider repeater list
		$this->add_control(
			'vertical_slider_list',
			[
				'label' => __( 'Add Slider', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'description' => 'Please Read description properly.editing image is tricky here.so matching is important.image field is not for exact this title',
				'default' => [
					[
						'vertical_slider_title' => __( 'Title #1', 'elgutts' ),
						'vertical_slider_subtitle' => __('Subtitle #1'),
                        'slider_bg_color'          => sanitize_hex_color('#FD3555'),
                        'vertical_slider_image'    => esc_url('https://images.unsplash.com/photo-1508768787810-6adc1f613514?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=e27f6661df21ed17ab5355b28af8df4e&auto=format&fit=crop&w=1350&q=80'),
					],
					[
						'vertical_slider_title' => __( 'Title #2', 'elgutts' ),
						'vertical_slider_subtitle' => __('Subtitle #2','elgutts'),
                        'slider_bg_color'          => sanitize_hex_color('#2A86BA'),
                        'vertical_slider_image'    => esc_url('https://images.unsplash.com/photo-1519981593452-666cf05569a9?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=90ed8055f06493290dad8da9584a13f7&auto=format&fit=crop&w=715&q=80'),
					],
					[
						'vertical_slider_title' => __( 'Title #3', 'elgutts' ),
						'vertical_slider_subtitle' => __('Subtitle #3','elgutts'),
                        'slider_bg_color'          => sanitize_hex_color('#252E33'),
                        'vertical_slider_image'    => esc_url('https://images.unsplash.com/photo-1486899430790-61dbf6f6d98b?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=8ecdee5d1b3ed78ff16053b0227874a2&auto=format&fit=crop&w=1002&q=80'),
					],
					[
						'vertical_slider_title' => __( 'Title #4', 'elgutts' ),
						'vertical_slider_subtitle' => __('Subtitle #4','elgutts'),
                        'slider_bg_color'          => '#FFB866',
                        'vertical_slider_image'    => esc_url('https://images.unsplash.com/photo-1510942201312-84e7962f6dbb?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=da4ca7a78004349f1b63f257e50e4360&auto=format&fit=crop&w=1050&q=80'),
					],
				],
				'title_field' => '{{{ vertical_slider_title }}}',
			]
		);

		$this->end_controls_section();
		//Expending Cards Title style
        $this->start_controls_section(
			'slider_titles_style',
			[
				'label' => __('Gutts Title Style', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->add_control(
			'cards_title_color',
			[
				'label' => __( 'Title color', 'elgutt' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .left-slide h1' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_control(
			'cards_subtitle_color',
			[
				'label' => __( 'Sub Title color', 'elgutt' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .left-slide p' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'slider_title_typography',
				'label' => __( 'Slider Title Typography', 'elgutts' ),
				'selector' => '{{WRAPPER}} .left-slide h1',
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'slider_subtitle_typography',
				'label' => __( 'Slider Sub Title Typography', 'elgutts' ),
				'selector' => '{{WRAPPER}} .left-slide p',
			]
		);
        $this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		$repeater_settings = $settings['vertical_slider_list'];
	?>

<div class="slider-container">
      <div class="left-slide">
        <?php foreach($repeater_settings as $left_side): ?>
        <div style="background-color: <?php echo $left_side['slider_bg_color']; ?>">
          <h1><?php esc_html_e($left_side['vertical_slider_title'],'elgutts'); ?></h1>
          <p><?php esc_html_e($left_side['vertical_slider_subtitle'],'elgutts'); ?></p>
        </div>
        <?php endforeach; ?>
      </div>
      <div class="right-slide">
		<?php foreach($repeater_settings as $right_side): ?>
			<?php $image = $right_side['vertical_slider_image']; ?>
        <div style="background-image: url('<?php echo esc_url($image['url']); ?>');background-size:cover;"></div>
		<?php endforeach; ?>
      </div>
      <div class="action-buttons">
        <button class="down-button slider-btn">
          <i class="dashicons dashicons-arrow-up-alt"></i>
        </button>
        <button class="up-button slider-btn">
          <i class="dashicons dashicons-arrow-down-alt"></i>
        </button>
      </div>
    </div>

	<?php
	}
}
