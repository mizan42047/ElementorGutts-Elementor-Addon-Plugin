<?php

use Elementor\Widget_Base;

class Gutts_Password_Generator extends Widget_Base
{
	/**
	 * Get widget name.
	 *
	 * Retrieve widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name gutts_password_generator.
	 */
	public function get_name()
	{
		return 'gutts_password_generator';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * 
	 * @return string  Gutts Banner Slider.
	 */
	public function get_title()
	{
		return __('Gutts Password Generator', 'elgutts');
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve gutts widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon dashicons-editor-paste-text.
	 */
	public function get_icon()
	{
		return 'dashicons dashicons-editor-paste-text';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the gutts widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['elgutts'];
	}

	/**
	 * Get widget construct.
	 *
	 * Retrieve the style and script of the Gutts password generator Widgets.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void.
	 */
	public function __construct($data = [], $args = null)
	{
		parent::__construct($data, $args);
		/* Script adding Area */
		wp_register_script('password-generator',plugin_dir_url(__DIR__).'assets/js/password-generator.js',[],'1.0.0',true);

		/* Style Adding Area */
		wp_register_style('password-generator',plugin_dir_url(__DIR__).'assets/css/password-generator.css');
	}


	public function get_script_depends()
	{
		return ['password-generator'];
	}

	public function get_style_depends()
	{
		return ['password-generator'];
		
	}

	/**
	 * Register Gutts widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{
        //PG Content Section
		$this->start_controls_section(
			'pg_content_section',
			[
				'label' => __('Content', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        //PG Title
        $this->add_control(
			'pg_title',
			[
				'label' => __( 'Generator Title', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
                'default' => __('Password Generator'),
			]
		);
        //PG Button Title
        $this->add_control(
			'pg_btn_title',
			[
				'label' => __( 'Submit Button Title', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
                'default' => __('Genarate Password'),
			]
		);

        $this->end_controls_section();
        //PG BG Section
		$this->start_controls_section(
			'gutts_pass_gen_bg_sec',
			[
				'label' => __('Password Generator Background', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
        //PG Backgound Color
        $this->add_control(
			'pg_bacground',
			[
				'label' => __( 'Generator Background Color', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pc-container' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_section();
        //PG Title Section
		$this->start_controls_section(
			'gutts_pass_gen_title_sec',
			[
				'label' => __('Password Generator Title', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
        //pg title color
        $this->add_control(
			'pg_title_color',
			[
				'label' => __( 'Title Color', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pc-header' => 'color: {{VALUE}}',
				],
			]
		);
        //pg title typography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'pg_title_typography',
				'label' => __( 'Typography', 'elgutts' ),
				'selector' => '{{WRAPPER}} .pc-header',
			]
		);
        //pg title align
        $this->add_control(
			'pg_title_align',
			[
				'label' => __( 'Title Alignment', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'elgutts' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'elgutts' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'elgutts' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
			]
		);
		$this->end_controls_section();
        //Result Container Section
		$this->start_controls_section(
			'result_section',
			[
				'label' => __('Result window', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//pg result bg
        $this->add_control(
			'pg_result_bg',
			[
				'label' => __( 'Result Window Background', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .result-container' => 'background-color: {{VALUE}}',
				],
			]
		);
        $this->end_controls_section();
        //Result Container Section
		$this->start_controls_section(
			'pg_small_text_section',
			[
				'label' => __('Small Text', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		//pg_small_text_typography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'pg_small_text_typography',
				'label' => __( 'Label Typography', 'elgutts' ),
				'selector' => '{{WRAPPER}} .setting label',
			]
		);

		//pg_small_text_color
        $this->add_control(
			'pg_small_text_color',
			[
				'label' => __( 'Label Color', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .setting label' => 'color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_section();
        //PG Button
		$this->start_controls_section(
			'pg_btn_section',
			[
				'label' => __('Buttons', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		//pg_btn_color
        $this->add_control(
			'pg_btn_color',
			[
				'label' => __( 'Button Text Color', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pc-btn' => 'color: {{VALUE}}',
				],
			]
		);

		//pg_btn_bg_color
        $this->add_control(
			'pg_btn_bg_color',
			[
				'label' => __( 'Button Background', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pc-btn' => 'background-color: {{VALUE}}',
				],
			]
		);

        //pg_btn_typography
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'pg_btn_typography',
				'label' => __( 'Button Typography', 'elgutts' ),
				'selector' => '{{WRAPPER}} .pc-btn-large',
			]
		);

		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();		
		
	?>

    <div class="pc-container">
      <h2 class="pc-header" style="text-align:<?php esc_attr_e($settings['pg_title_align']); ?>"><?php esc_html_e($settings['pg_title'],'elgutts'); ?></h2>
      <div class="result-container">
        <span id="result"></span>
        <button class="pc-btn" id="clipboard">
          <i class="dashicons dashicons-clipboard"></i>
        </button>
      </div>
      <div class="settings">
        <div class="setting">
          <label>Password Length</label>
          <input type="number" id="length" min="4" max="20" value="20">
        </div>
        <div class="setting">
          <label>Include uppercase letters</label>
          <input type="checkbox" id="uppercase" checked>
        </div>
        <div class="setting">
          <label>Include lowercase letters</label>
          <input type="checkbox" id="lowercase" checked>
        </div>
        <div class="setting">
          <label>Include numbers</label>
          <input type="checkbox" id="numbers" checked>
        </div>
        <div class="setting">
          <label>Include symbols</label>
          <input type="checkbox" id="symbols" checked>
        </div>
      </div>

      <button class="pc-btn pc-btn-large" id="generate">
        <?php esc_html_e($settings['pg_btn_title'],'elgutts'); ?>
      </button>
    </div>

	<?php
	}
}
