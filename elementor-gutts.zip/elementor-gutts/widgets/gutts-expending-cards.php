<?php

use Elementor\Widget_Base;

class Gutts_Expending_Cards extends Widget_Base
{
	/**
	 * Get widget name.
	 *
	 * Retrieve widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name gutts_banner_slider.
	 */
	public function get_name()
	{
		return 'gutts_expanding_cards';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string  Gutts Banner Slider.
	 */
	public function get_title()
	{
		return __('Gutts Expending Cards', 'elgutts');
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve gutts banner slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon dashicons-slides.
	 */
	public function get_icon()
	{
		return 'dashicons dashicons-index-card';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the gutts banner slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['elgutts'];
	}

	/**
	 * Get widget construct.
	 *
	 * Retrieve the style and script of the Gutts Slider Widgets.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void.
	 */
	public function __construct($data = [], $args = null)
	{
		parent::__construct($data, $args);
		/* Script adding Area */
		wp_register_script('expending-cards',plugin_dir_url(__DIR__).'assets/js/expending-cards.js',[],'1.0.0',true);

		/* Style Adding Area */
		wp_register_style('expending-cards',plugin_dir_url(__DIR__).'assets/css/expending-cards.css');
	}


	public function get_script_depends()
	{
		return ['expending-cards'];
	}

	public function get_style_depends()
	{
		return ['expending-cards'];
		
	}

	/**
	 * Register Gutts banner widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{

		$this->start_controls_section(
			'gutts_expending_cards',
			[
				'label' => __('Gutts Expending Cards', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'expending_cards_title',
			[
				'label' => __('Card Title', 'elgutts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __('Write Title', 'elgutts'),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'expending_cards_image',
			[
				'label' => __( 'Card Images', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'expending_cards_list',
			[
				'label' => __( 'Add Expending Cards', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'expending_cards_title' => __( 'Title #1', 'elgutts' ),
						'expending_cards_image' => esc_url('https://images.unsplash.com/photo-1601933973783-43cf8a7d4c5f?ixid=MXwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80'),
					],
					[
						'expending_cards_title' => __( 'Title #2', 'elgutts' ),
						'expending_cards_image' => esc_url('https://images.unsplash.com/photo-1519222970733-f546218fa6d7?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80'),
					],
					[
						'expending_cards_title' => __( 'Title #3', 'elgutts' ),
						'expending_cards_image' => esc_url('https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80'),
					],
					[
						'expending_cards_title' => __( 'Title #4', 'elgutts' ),
						'expending_cards_image' => esc_url('https://images.unsplash.com/photo-1502945015378-0e284ca1a5be?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80'),
					],
				],
				'title_field' => '{{{ expending_cards_title }}}',
			]
		);

		$this->end_controls_section();
		//Expending Cards Title style
        $this->start_controls_section(
			'cards_title_style',
			[
				'label' => __('Gutts Card Title', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->add_control(
			'cards_title_bg_color',
			[
				'label' => __( 'Title Background', 'elgutt' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .heading' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'cards_title_color',
			[
				'label' => __( 'Title Color', 'elgutt' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .heading' => 'color: {{VALUE}}',
				],
			]
		);
        $this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		$repeater_settings = $settings['expending_cards_list'];
	?>

	<div class="container">
		<?php if($repeater_settings):foreach($repeater_settings as $card_data): ?>
		<?php 
			$image_url = $card_data['expending_cards_image']['url'];
			$card_title = $card_data['expending_cards_title'];
		?>
        <div class="panel" style="background-image: linear-gradient(rgba(0,0,0,.5),rgba(0,0,0,.5)),url('<?php echo esc_url($image_url) ?>')">
            <h3 class="heading"><?php esc_html_e($card_data['expending_cards_title'],'elgutts'); ?></h3>
        </div>
		<?php endforeach;endif; ?>
    </div>

	<?php
	}
}
