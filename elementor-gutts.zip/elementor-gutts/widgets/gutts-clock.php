<?php

use Elementor\Widget_Base;

class Gutts_Clock extends Widget_Base
{
	/**
	 * Get widget name.
	 *
	 * Retrieve widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name gutts_clock.
	 */
	public function get_name()
	{
		return 'gutts_clock';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * 
	 * @return string  Gutts Banner Slider.
	 */
	public function get_title()
	{
		return __('Gutts Clock', 'elgutts');
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve gutts widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon dashicons-clock.
	 */
	public function get_icon()
	{
		return 'dashicons dashicons-clock';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the gutts widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['elgutts'];
	}

	/**
	 * Get widget construct.
	 *
	 * Retrieve the style and script of the Gutts Slider Widgets.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void.
	 */
	public function __construct($data = [], $args = null)
	{
		parent::__construct($data, $args);
		/* Script adding Area */
		wp_register_script('gutts-clock',plugin_dir_url(__DIR__).'assets/js/clock.js',[],'1.0.0',true);

		/* Style Adding Area */
		wp_register_style('gutts-clock',plugin_dir_url(__DIR__).'assets/css/clock.css');
	}


	public function get_script_depends()
	{
		return ['gutts-clock'];
	}

	public function get_style_depends()
	{
		return ['gutts-clock'];
		
	}

	/**
	 * Register Gutts widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{
        //Enalog Clock Section
		$this->start_controls_section(
			'gutts_clock_enalog_section',
			[
				'label' => __('Enalog Clock Style', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
        //clock middle circle color
        $this->add_control(
			'clock_circle_color',
			[
				'label' => __( 'Clock Middle Point Color', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .center-point' => 'background-color: {{VALUE}}',
				],
			]
		);
        //clock hour needle color
        $this->add_control(
			'clock_hour_needle_color',
			[
				'label' => __( 'Hour Needle Color', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .needle.hour' => 'background-color: {{VALUE}}',
				],
			]
		);

        //clock Minute needle color
        $this->add_control(
			'clock_minute_needle_color',
			[
				'label' => __( 'Minute Needle Color', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .needle.minute' => 'background-color: {{VALUE}}',
				],
			]
		);
        //clock Second needle color
        $this->add_control(
			'clock_second_needle_color',
			[
				'label' => __( 'Second Needle Color', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .needle.second' => 'background-color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();
        //Digital Clock Section
		$this->start_controls_section(
			'gutts_clock_digital_section',
			[
				'label' => __('Digital Clock Style', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		//clock time color
        $this->add_control(
			'clock_time_color',
			[
				'label' => __( 'Clock Time Color', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .time' => 'color: {{VALUE}}',
				],
			]
		);

		//clock time typograpy
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'clock_time_typography',
				'label' => __( 'Clock Time Typography', 'elgutts' ),
				'selector' => '{{WRAPPER}} .time',
			]
		);

		//clock date color
        $this->add_control(
			'clock_date_color',
			[
				'label' => __( 'Clock Date Color', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .date' => 'color: {{VALUE}}',
				],
			]
		);

		//clock day color
        $this->add_control(
			'clock_day_color',
			[
				'label' => __( 'Clock Day Color', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
                'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .date .clock-circle' => 'color: {{VALUE}}',
				],
			]
		);

		//clock day  background-color
        $this->add_control(
			'clock_day_bg_color',
			[
				'label' => __( 'Clock Day Background Color', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .date .clock-circle' => 'background-color: {{VALUE}}',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();		
		
	?>

    <div class="clock-container">
      <div class="clock">
        <div class="needle hour"></div>
        <div class="needle minute"></div>
        <div class="needle second"></div>
        <div class="center-point"></div>
      </div>

      <div class="time"></div>
      <div class="date"></div>
    </div>

	<?php
	}
}
