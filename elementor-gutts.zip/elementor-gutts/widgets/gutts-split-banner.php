<?php

use Elementor\Widget_Base;

class Gutts_Split_Banner extends Widget_Base
{
	/**
	 * Get widget name.
	 *
	 * Retrieve widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name gutts_split_banner.
	 */
	public function get_name()
	{
		return 'gutts_split_banner';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string  Gutts Banner Slider.
	 */
	public function get_title()
	{
		return __('Gutts Split Banner', 'elgutts');
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve gutts widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon dashicons-welcome-widgets-menus.
	 */
	public function get_icon()
	{
		return 'dashicons dashicons-welcome-widgets-menus';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the gutts banner slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['elgutts'];
	}

	/**
	 * Get widget construct.
	 *
	 * Retrieve the style and script of the Gutts Slider Widgets.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void.
	 */
	public function __construct($data = [], $args = null)
	{
		parent::__construct($data, $args);
		/* Script adding Area */
		wp_register_script('split-banner',plugin_dir_url(__DIR__).'assets/js/split-banner.js',[],'1.0.0',true);

		/* Style Adding Area */
		wp_register_style('split-banner',plugin_dir_url(__DIR__).'assets/css/split-banner.css');
	}


	public function get_script_depends()
	{
		return ['split-banner'];
	}

	public function get_style_depends()
	{
		return ['split-banner'];
		
	}

	/**
	 * Register Gutts widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{
        //Left Background
		$this->start_controls_section(
			'gutts_split_banner_left',
			[
				'label' => __('Gutts Split Banner Left', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
        //Split banner Left Title
        $this->add_control(
			'left_title_split',
			[
				'label' => __( 'Left Split Title', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'PLAY STATION 5', 'elgutts' ),
                'separator' => 'after',
				'label_block' => true,
			]
		);
        //tabs start for button
        $this->start_controls_tabs(
			'style_tabs_left'
		);
        //button title tab
        $this->start_controls_tab(
			'split_content_tab',
			[
				'label' => __( 'Split Button Left', 'elgutts' ),
			]
		);
        //title control split left Button
        $this->add_control(
			'left_button_split_title',
			[
				'label' => __( 'Left Button Text', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Buy Now', 'elgutts' ),
                'label_block' => true,
			]
		);
        //Url control split left button
        $this->add_control(
			'left_button_split_url',
			[
				'label' => __( 'Button Link', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'elgutts' ),
				'show_external' => true,
				'default' => [
					'url' => 'https://mijandev.com',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

        $this->end_controls_tab();
        //Stype tab for style left split button
        $this->start_controls_tab(
			'split_style_tab_left',
			[
				'label' => __( 'Split Button Style', 'elgutts' ),
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'split_left_btn_typography',
				'label' => __( 'Button Typography', 'elgutts' ),
				'selector' => '{{WRAPPER}} .spilit.left h1',
			]
		);

        $this->end_controls_tab();
        $this->end_controls_tabs();
		//background for left split
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'left_background_split',
				'label' => __( 'Left Background', 'elgutts' ),
				'types' => [ 'classic', 'gradient' ],
                'separator' => 'before',
				'selector' => '{{WRAPPER}} .spilit.left',
				'label_block' => true,
				'show_label' => true,
			]
		);
		

		$this->end_controls_section();
        //Section for right split
		$this->start_controls_section(
			'gutts_split_banner_right',
			[
				'label' => __('Gutts Split Banner right', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		//Right split title
        $this->add_control(
			'right_title_split',
			[
				'label' => __( 'Right Split Title', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'XBOX SERIES X', 'elgutts' ),
				'label_block' => true,
			]
		);

		//tabs start for button
        $this->start_controls_tabs(
			'style_tabs_right'
		);
        //button title tab
        $this->start_controls_tab(
			'split_content_tab_right',
			[
				'label' => __( 'Split Button Right', 'elgutts' ),
			]
		);
        //title control split right Button
        $this->add_control(
			'right_button_split_title',
			[
				'label' => __( 'Right Button Text', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Buy Now', 'elgutts' ),
                'label_block' => true,
			]
		);
        //Url control split right button
        $this->add_control(
			'right_button_split_url',
			[
				'label' => __( 'Button Link', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'elgutts' ),
				'show_external' => true,
				'default' => [
					'url' => 'https://mijandev.com',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

        $this->end_controls_tab();
        //Stype tab for style right split button
        $this->start_controls_tab(
			'split_style_tab_right',
			[
				'label' => __( 'Split Button Style', 'elgutts' ),
			]
		);
		//Right Background
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'split_right_btn_typography',
				'label' => __( 'Button Typography', 'elgutts' ),
				'selector' => '{{WRAPPER}} .spilit.right h1',
			]
		);

        $this->end_controls_tab();
        $this->end_controls_tabs();
		
		//background for right split
        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'right_background_split',
				'label' => __( 'Right Background', 'elgutts' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .spilit.right',
				'separator' => 'before',
			]
		);
		

		$this->end_controls_section();
	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		$left_title = $settings['left_title_split'];
		$left_btn_text = $settings['left_button_split_title'];
		$left_btn_url = $settings['left_button_split_url']['url'];

		$right_title = $settings['right_title_split'];
		$right_btn_text = $settings['right_button_split_title'];
		$right_btn_url = $settings['right_button_split_url']['url'];
		
		
	?>

    <div class="container__split">
        <div class="spilit left">
            <h1><?php esc_html_e($left_title,'elgutts'); ?></h1>
            <a href="<?php echo esc_url($left_btn_url); ?>" class="btn-split"><?php esc_html_e($left_btn_text,'elgutts'); ?></a>
        </div>
        <div class="spilit right">
            <h1><?php esc_html_e($right_title,'elgutts'); ?></h1>
            <a href="<?php echo esc_url($right_btn_url); ?>" class="btn-split"><?php esc_html_e($right_btn_text,'elgutts'); ?></a>
        </div>
    </div>

	<?php
	}
}
