<?php

use Elementor\Widget_Base;

class Gutts_Progress_Steps extends Widget_Base
{
	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name gutts_progress_steps.
	 */
	public function get_name()
	{
		return 'gutts_progress_steps';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string  Gutts Progress Step.
	 */
	public function get_title()
	{
		return __('Gutts Progress Step', 'elgutts');
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve gutts progress widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon dashicons-slides.
	 */
	public function get_icon()
	{
		return 'dashicons dashicons-editor-ol';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories()
	{
		return ['elgutts'];
	}

	/**
	 * Get widget construct.
	 *
	 * Retrieve the style and script of the Widgets.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void.
	 */
	public function __construct($data = [], $args = null)
	{
		parent::__construct($data, $args);
		/* Script adding Area */
		wp_register_script('progress-steps',plugin_dir_url(__DIR__).'assets/js/progress-steps.js',[],'1.0.0',true);

		/* Style Adding Area */
		wp_register_style('progress-steps',plugin_dir_url(__DIR__).'assets/css/progress-steps.css');
	}


	public function get_script_depends()
	{
		return ['progress-steps'];
	}

	public function get_style_depends()
	{
		return ['progress-steps'];
		
	}

	/**
	 * Register Gutts widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls()
	{
        //Repeater for progress steps number
		$this->start_controls_section(
			'gutts_progress_steps',
			[
				'label' => __('Gutts Progress Steps', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'progress_steps_title',
			[
				'label' => __('Progress Symbol', 'elgutts'),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'text',
				'placeholder' => __('Write Title', 'elgutts'),
				'label_block' => true,
			]
		);
		$this->add_control(
			'progress_steps_list',
			[
				'label' => __( 'Add Progress Steps', 'elgutts' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'progress_steps_title' => __( '#1', 'elgutts' ),
					],
					[
						'progress_steps_title' => __( '#2', 'elgutts' ),
					],
					[
						'progress_steps_title' => __( '#3', 'elgutts' ),
					],
					[
						'progress_steps_title' => __( '#4', 'elgutts' ),
					],
				],
				'title_field' => '{{{ progress_steps_title }}}',
			]
		);

		$this->end_controls_section();
        //Progress Number style
        $this->start_controls_section(
			'gutts_progress_style',
			[
				'label' => __('Gutts Progress Style', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->add_control(
			'progress_line_color',
			[
				'label' => __( 'Progress Line Color', 'elgutt' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progress' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'circle_border_color',
			[
				'label' => __( 'Circle Border Color', 'elgutt' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .circle.cactive' => 'border-color: {{VALUE}}',
				],
			]
		);
        $this->end_controls_section();

        //Progress button style
        $this->start_controls_section(
			'gutts_progress_btn_style',
			[
				'label' => __('Progress Button Style', 'elgutts'),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->add_control(
			'btn_bg_color',
			[
				'label' => __( 'Button Background', 'elgutt' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn' => 'background-color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'btn_text_color',
			[
				'label' => __( 'Button Text Color', 'elgutt' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn' => 'color: {{VALUE}}',
				],
			]
		);
        $this->end_controls_section();


	}

	protected function render()
	{
		$settings = $this->get_settings_for_display();
		$repeater_settings = $settings['progress_steps_list'];
	?>

<div class="progress__main">
        <div class="progress-container">
            <div class="progress" id="progress"></div>
			<?php if($repeater_settings): foreach($repeater_settings as $steps_num): ?>
            <div class="circle"><?php esc_html_e($steps_num['progress_steps_title'],'elgutts'); ?></div>
			<?php endforeach;endif; ?>
        </div>
        <button class="btn" id="prev" disabled>Prev</button>
        <button class="btn" id="next">Next</button>
    </div>

	<?php
	}
}
