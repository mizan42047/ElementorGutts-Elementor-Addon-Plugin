<?php 
/**
 * Elementor emoji one area control.
 *
 * A control for displaying a textarea with the ability to add emojis.
 *
 * @since 1.0.0
 */
class Post_Select_Control extends \Elementor\Base_Data_Control {

	/**
	 * Get post type select area control type.
	 *
	 * Retrieve the control type, in this case `emojionearea`.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Control type.
	 */
	public function get_type() {
		return 'post_select';
    }

	/**
	 * Render post type control output in the editor.
	 *
	 * Used to generate the control HTML in the editor using Underscore JS
	 * template. The variables for the class are available using `data` JS
	 * object.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function content_template() {
		?>
		<div class="elementor-control-field">
			<label class="elementor-control-title">{{{ data.label }}}</label>
			<select class="post-select" name="post_select" style="width:100%" data-setting="{{ data.name }}">
            <?php 
            $post_types = get_post_types(['public'=>true,'_builtin'=>false,]);
            foreach($post_types as $post_type){
                $exclude = ['e-landing-page','elementor_library'];
                if(in_array($post_type,$exclude))continue;                
                printf('<option value="%s">%s</option>',$post_type,$post_type);
            }
            
            ?>   
            </select>
		</div>
		<?php
	}

}